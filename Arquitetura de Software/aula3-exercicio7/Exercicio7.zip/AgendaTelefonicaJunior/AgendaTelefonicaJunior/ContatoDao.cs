﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AgendaTelefonicaJunior
{
    public class ContatoDao : IContatoDao
    {
        private List<Contato> contatos = new List<Contato>();

        public List<Contato> buscar(string nome)
        {
            List<Contato> resultado = new List<Contato>();
            foreach(Contato c in contatos)
            {
                if (nome.Equals(c.nome))
                    resultado.Add(c);
            }
            return resultado;
        }

        public bool existe(Contato c)
        {
            return contatos.Contains(c);
        }

        public void inserir(Contato c)
        {
            contatos.Add(c);
        }
    }
}
