﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AgendaTelefonicaJunior
{
    class Program
    {

        private static IContatoDao dao;

        static void Main(string[] args)
        {
            bool sair = false;
            while (!sair)
            {
                int opcao = apresentarMenuPrincipal();
                switch (opcao)
                {
                    case 1: { inserirContato(); break; }
                    case 2: { buscarContato(); break; }
                    case 3: { sair = true; break; }
                    default: { Console.WriteLine("ERRO: opção inválida!"); break; }
                }
            }
        }

        private static int apresentarMenuPrincipal()
        {
            bool inteiro = false;
            int opcao = 0;
            while (!inteiro)
            {
                Console.WriteLine("\nAGENDA TELEFÔNICA");
                Console.WriteLine("(1) Inserir");
                Console.WriteLine("(2) Buscar");
                Console.WriteLine("(3) Sair");
                Console.WriteLine("Escolha uma opção: ");
                String s = Console.ReadLine();
                try
                {
                    opcao = Int32.Parse(s);
                    inteiro = true;
                }
                catch (Exception e)
                {
                    Console.WriteLine("ERRO: opção deve ser um valor inteiro!");
                }
            }
            return opcao;
        }

        private static void inserirContato()
        {
            Console.WriteLine("\nINSERCAO DE NOVO CONTATO:");
            String nome = lerNome();
            String telefone = lerTelefone();
            Contato c = new Contato() { nome = nome, telefone = telefone };
            if (dao.existe(c))
            {
                Console.WriteLine("Esse contato já está cadastrado!");
            }
            else
            {
                dao.inserir(c);
                Console.WriteLine("Contato inserido!");
            }
        }

        private static string lerNome()
        {
            bool valido = false;
            string nome = string.Empty;
            while (!valido)
            {
                Console.WriteLine("Nome: ");
                nome = Console.ReadLine();
                if (nome.Length == 0 || nome.Length > 200)
                {
                    Console.WriteLine("ERRO: nome de tamanho inválido!");
                }
                else
                {
                    valido = true;
                }
            }
            return nome;
        }

        private static string lerTelefone()
        {
            bool valido = false;
            string telefone = string.Empty;
            while (!valido)
            {
                Console.WriteLine("Telefone: ");
                telefone = Console.ReadLine();
                if (telefone.Length == 0 || telefone.Length > 25)
                {
                    Console.WriteLine("ERRO: telefone de tamanho inválido!");
                }
                else
                {
                    valido = true;
                }
            }
            return telefone;
        }

        private static void buscarContato()
        {
            Console.WriteLine("\nBUSCA DE CONTATOS:");
            string nome = lerNome();
            List<Contato> resultado = dao.buscar(nome);
            if (resultado.Count() == 0)
                Console.WriteLine("Não há contato com este nome!");
            else
            {
                Console.WriteLine("\nResultado da busca:");
                foreach (Contato c in resultado)
                    Console.WriteLine(c);
            }
        }


    }
}
