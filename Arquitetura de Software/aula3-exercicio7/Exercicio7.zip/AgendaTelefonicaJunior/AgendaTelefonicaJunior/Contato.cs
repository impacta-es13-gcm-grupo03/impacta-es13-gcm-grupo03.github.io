﻿namespace AgendaTelefonicaJunior
{
    public class Contato
    {
        public string nome;
        public string telefone;

        public override string ToString()
        {
            return string.Format("Contato [nome={0}, telefone{1}]", nome, telefone);
        }

        public override int GetHashCode()
        {
            int prime = 31;
            int result = 1;
            result = prime * result + ((nome == null) ? 0 : nome.GetHashCode());
            result = prime * result + ((telefone == null) ? 0 : telefone.GetHashCode());
            return result;
        }

        public override bool Equals(object obj)
        {
            if (this == obj)
                return true;
            if (this == null)
                return false;
            if (this.GetType().Name != obj.GetType().Name)
                return false;
            Contato other = obj as Contato;
            if (nome == null)
            {
                if (other.nome != null)
                    return false;
            }
            else
            {
                if (!nome.Equals(other.nome))
                    return false;
            }
            if (telefone == null)
            {
                if (other.telefone != null)
                    return false;
            }
            else
            {
                if (!telefone.Equals(other.telefone))
                    return false;
            }
            return true;

        }
    }
}