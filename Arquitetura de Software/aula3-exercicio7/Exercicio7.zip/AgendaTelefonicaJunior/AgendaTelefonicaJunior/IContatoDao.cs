﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AgendaTelefonicaJunior
{
    public interface IContatoDao
    {
        List<Contato> buscar(string nome);
        void inserir(Contato c);
        bool existe(Contato c);
    }
}
